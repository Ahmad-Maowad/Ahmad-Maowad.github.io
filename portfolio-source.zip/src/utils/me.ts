export const name='Ahmad Maowad';
export const email='ahmadmaowad2@gmail.com';
export const phone='+966 53 272 1500';
export const linkedin_url='https://www.linkedin.com/in/ahmad-maowad/';
export const behance_url='https://www.behance.net/ahmadmaowad';
export const homepage_url='https://sites.google.com/view/ahmadmaowad/home';
