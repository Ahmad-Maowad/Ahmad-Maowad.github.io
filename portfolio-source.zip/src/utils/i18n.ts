import en from '../i18n/en.json';
import ar from '../i18n/ar.json';
export type Lang='ar'|'en';
export function t(path:string,lang:string='ar'):string {let v:any=lang==='en'?en:ar; for(const k of path.split('.'))v=v?.[k];return typeof v==='string'?v:path;}
export function getTranslations(lang:string='ar'){return lang==='en'?en:ar;}
