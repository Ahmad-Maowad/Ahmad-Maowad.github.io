import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';
export default defineConfig({
 site:'https://ahmad-maowad.github.io',
 output:'static',trailingSlash:'always',
 i18n:{defaultLocale:'ar',locales:['ar','en'],routing:{prefixDefaultLocale:true}},
 integrations:[tailwind(),sitemap()],
 server:{allowedHosts:['terminal.local']}
});
