# Template provenance
Based on nicremo/astro-multilingual-portfolio-template (MIT).
Source: https://github.com/nicremo/astro-multilingual-portfolio-template
Imported commit: 2dd4f0f9891f9b217f237dff02c4933f0054740e
Customized for Ahmad Maowad: Arabic/English content, RTL, project galleries, filtering, accessible image viewer, experience and CV downloads.
Project images belong to their respective authors/clients; the template license does not license portfolio media for reuse.
