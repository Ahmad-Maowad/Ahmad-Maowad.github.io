export default {content:['./src/**/*.{astro,html,js,ts}'],darkMode:'class',theme:{extend:{colors:{primary:'#0A84FF',secondary:'#102039',neutral:{bg:'#F5F8FC',dark:'#0D1117'}}}},plugins:[]};
